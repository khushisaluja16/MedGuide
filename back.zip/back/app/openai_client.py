# backend/app/openai_client.py
import os
import json
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "..", "..", ".env"))
from google import genai


client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))


PROMPT_TEMPLATE = """
You are a professional medical assistant summarizer (non-diagnostic). Input: patient metadata and vitals with comparison results.
Return a JSON with keys: "summary", "risk_assessment", "possible_conditions", "recommended_tests", "preventive_measures", "lifestyle_suggestions".
Be concise. Use plain, patient-friendly language. Base answers only on the provided vitals and flags. If data is missing, say what you could not check.
Input data:
{data}
"""

def analyze_with_openai(vitals_payload, comparison_result):
    data = {
        "patient": {
            "name": vitals_payload.get("name"),
            "age": vitals_payload.get("age"),
            "gender": vitals_payload.get("gender"),
        },
        "vitals": vitals_payload.get("vitals"),
        "comparison": comparison_result
    }
    prompt = PROMPT_TEMPLATE.format(data=json.dumps(data, indent=2))

    response = client.models.generate_content(
        model="models/gemini-2.5-flash",
        contents=prompt
    )

    try:
        return json.loads(response.text)
    except:
        return {"raw_text": response.text}