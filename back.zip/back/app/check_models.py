from google import genai
import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "..", "..", ".env"))

client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

models = client.models.list()

print("\nAvailable Models:\n")

for model in models:
    print(model.name)